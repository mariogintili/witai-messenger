require('es7-array.prototype.includes');


module.exports.hello = (event, context, callback) => {
  const body     = JSON.parse(event.body);
  console.log(JSON.stringify(body, null, '\t'));
  const response = {
    statusCode: 200,
    headers: {},
    body: event.query['hub.challenge']
  };

  return callback(null, response);
};
