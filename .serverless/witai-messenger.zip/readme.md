# witai-messenger

This is project exposes a serverless service using Node.JS to mash-up the Facebook Messenger platform and wit.ai. More information coming soon
